#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
from save_format import inspect_save, patch_money

p=argparse.ArgumentParser(description='STALKER 2 save money editor')
sub=p.add_subparsers(dest='cmd',required=True)
i=sub.add_parser('info'); i.add_argument('save')
e=sub.add_parser('set-money'); e.add_argument('save'); e.add_argument('money',type=int); e.add_argument('-o','--output')
a=p.parse_args()

data=Path(a.save).read_bytes()
if a.cmd=='info':
    x=inspect_save(data)
    print(f'CRC: OK\nPacked: {x.packed_size}\nRaw: {x.unpacked_size}\nMoney: {x.money}')
else:
    out,old,new=patch_money(data,a.money)
    dst=Path(a.output) if a.output else Path(a.save).with_name(Path(a.save).stem+'_edited.sav')
    dst.write_bytes(out)
    print(f'{old} -> {new}\nOutput: {dst}\nSize: {len(out)}')
