#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
DESK="$HOME/.local/share/applications/stalker2-cloud-save-editor.desktop"
mkdir -p "$(dirname "$DESK")"
cat > "$DESK" <<EOF
[Desktop Entry]
Type=Application
Name=STALKER 2 Cloud Save Editor
Comment=Edit coupons and upload STALKER 2 saves to Steam Cloud
Exec=$DIR/run.sh
Terminal=false
Categories=Game;Utility;
EOF
chmod +x "$DESK"
echo "Установлен ярлык: $DESK"
