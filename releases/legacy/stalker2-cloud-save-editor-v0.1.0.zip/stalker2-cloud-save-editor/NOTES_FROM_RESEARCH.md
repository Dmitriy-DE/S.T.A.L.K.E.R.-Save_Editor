# S.T.A.L.K.E.R. 2 — редактирование купонов в Steam Cloud без установки игры

> Рабочие заметки и инструкция для Linux + Steam + GeForce NOW.
>
> Цель: скачать `.sav` из Steam Cloud, поменять баланс купонов локально, проверить целостность и загрузить сейв обратно, не скачивая всю игру.

---

## 1. Что уже получилось

Мы подтвердили на реальных сейвах S.T.A.L.K.E.R. 2, что:

- полноценные игровые сейвы лежат в:

```text
Stalker2/Saved/STEAM/SaveGames/Data/
```

- файлы из:

```text
Stalker2/Saved/STEAM/SaveGames/Thumbnails/
```

  — это превью/картинки, а не игровые данные;

- `.sav` использует блочное Oodle/Kraken-сжатие;
- open-source декомпрессор из `pyooz` подходит для распаковки;
- последние 4 байта `.sav` — CRC32 содержимого файла перед ними;
- после правки CRC можно корректно пересчитать;
- весь файл необязательно снова сжимать Kraken: изменённый блок можно хранить несжатым, если контейнер собран корректно;
- получившийся файл можно повторно распаковать и проверить до загрузки в Steam Cloud.

### Проверенный Python wheel

```text
pyooz-0.0.8-cp38-abi3-manylinux_2_17_x86_64.manylinux2014_x86_64.whl
```

Скачать его на Linux можно так:

```bash
cd ~
python3 -m pip download --no-deps --only-binary=:all: pyooz==0.0.8
```

Если запускать `pip download` из `/`, будет `PermissionError`, потому что обычный пользователь не может записывать файлы в корень ФС.

---

## 2. App ID игры

Steam App ID S.T.A.L.K.E.R. 2:

```text
1643320
```

Он понадобится для работы со Steam Cloud через сторонний менеджер.

---

## 3. Контрольные сейвы, на которых нашли деньги

Были получены несколько близких по времени сейвов и скриншоты баланса.

### Сейв в 16:44

```text
217BB29D4FA4C87BD9F734AE755338CB.sav
```

Баланс на скриншоте:

```text
48 645
```

### Сейв около 16:46

```text
D9338CF24B87162D6472C79DF9E1CFFE.sav
```

В распакованных данных было найдено значение:

```text
58 870
```

### Сейв в 16:47

```text
D639C0F24C64FC164326E8967A8DCCBE.sav
```

Баланс на скриншоте:

```text
56 995
```

Именно `D639...` был использован как база для модификации.

---

## 4. Как в сейве хранится баланс

На этих трёх сейвах точное значение баланса было найдено в распакованном payload как **little-endian 64-bit integer (`int64`)**.

Например, поиск обычного `int32` даёт ложные совпадения, потому что в огромном сейве встречается много таких же чисел.

При этом точное значение как `int64` в проверенных контрольных сейвах встречалось единственный раз, что позволило достаточно уверенно идентифицировать поле кошелька.

Это важный принцип будущего редактора:

1. пользователь вводит текущий баланс, который видит в игре;
2. программа распаковывает `.sav`;
3. ищет `int64(current_money)`;
4. если найдено **ровно одно** совпадение — его можно заменить;
5. если совпадений 0 или больше 1 — ничего автоматически не менять и просить дополнительную проверку.

Так безопаснее, чем использовать жёсткий offset, потому что смещения между разными сейвами меняются.

---

## 5. Готовый изменённый сейв

Исходный слот:

```text
D639C0F24C64FC164326E8967A8DCCBE.sav
```

Исходный баланс:

```text
56 995
```

Новый баланс:

```text
900 000
```

### SHA-256 оригинала

```text
bc7435ca9e22bde4646b2fa0f60fcf96040ab0f4e55a3bff1791c6fb7d8c0a3e
```

### SHA-256 изменённого файла

```text
ffc1839e66a76f2ece6a24a4c516c687388039379834b53a306642b5ab1f6e5e
```

### Проверки, сделанные после модификации

- пересчитан CRC32;
- CRC в последних 4 байтах совпадает с рассчитанным;
- изменённый контейнер снова успешно распаковывается;
- распакованный payload имеет ожидаемый размер;
- в поле баланса находится `900000`;
- имя слота сохранено тем же, чтобы можно было заменить существующий cloud-файл.

---

# 6. Как скачать правильный сейв из Steam Cloud

Официальная страница Remote Storage:

```text
https://store.steampowered.com/account/remotestorage/
```

Найти S.T.A.L.K.E.R. 2 и смотреть именно файлы вида:

```text
WinAppDataLocal
Stalker2/Saved/STEAM/SaveGames/Data/<ID>.sav
```

Нормальный игровой сейв обычно весит несколько мегабайт.

Не брать для редактирования денег:

```text
SaveGames/Thumbnails/
SaveGames/TempCampaigns/
CampaignsSave.sav
AnalyticsData.sav
```

`Thumbnails` особенно легко перепутать с настоящим сейвом, потому что ID файла такой же.

---

# 7. Как загрузить изменённый сейв обратно в Steam Cloud на Linux

Самый удобный вариант без установки всей игры — **Steam Cloud File Manager**:

```text
https://github.com/Fldicoahkiin/SteamCloudFileManager
```

Релизы:

```text
https://github.com/Fldicoahkiin/SteamCloudFileManager/releases
```

Поддерживаются Linux x64, AppImage, `.deb`, `.rpm` и generic binary.

## Вариант с AppImage

После скачивания:

```bash
chmod +x ~/Downloads/SteamCloudFileManager-*.AppImage
```

### 7.1. Полностью закрыть Steam

```bash
steam -shutdown
```

Подождать несколько секунд.

### 7.2. Запустить Steam с CEF debugging

```bash
steam -cef-enable-debugging &
```

Steam Cloud File Manager использует debug/CDP-интерфейс Steam для получения облачного списка и работает со Steam API для файловых операций.

### 7.3. Запустить менеджер

```bash
~/Downloads/SteamCloudFileManager-*.AppImage
```

### 7.4. Подключить S.T.A.L.K.E.R. 2

Использовать App ID:

```text
1643320
```

### 7.5. Найти исходный cloud-файл

Для нашего готового сейва:

```text
Root: WinAppDataLocal
Path: Stalker2/Saved/STEAM/SaveGames/Data/D639C0F24C64FC164326E8967A8DCCBE.sav
```

Важно: лучше сначала найти **существующий файл** в дереве и повторить его Root/Cloud Path один в один.

Не нужно создавать рядом файл с другим именем — цель именно заменить существующий слот.

### 7.6. Сделать ещё один backup

До upload скачать исходный `D639...sav` через менеджер и положить в отдельную папку, например:

```text
~/Backups/stalker2/
```

### 7.7. Upload / overwrite

Выбрать изменённый локальный файл:

```text
D639C0F24C64FC164326E8967A8DCCBE.sav
```

и загрузить его в тот же Root/Cloud Path, что у существующего облачного файла.

Если программа отдельно показывает Root и Path:

```text
Root = WinAppDataLocal
Path = Stalker2/Saved/STEAM/SaveGames/Data/D639C0F24C64FC164326E8967A8DCCBE.sav
```

### 7.8. Дождаться реальной синхронизации

Новый upload может сначала иметь:

```text
is_persisted = false
```

Это значит, что файл ещё находится в локальном cloud-кэше Steam.

Нужно дождаться:

```text
is_persisted = true
```

Это значит, что файл уже ушёл в Steam Cloud.

Не запускать GeForce NOW до этого момента.

---

# 8. Первый запуск через GeForce NOW после замены

1. Убедиться, что изменённый файл уже реально синхронизирован в Steam Cloud.
2. Только потом запускать S.T.A.L.K.E.R. 2 в GeForce NOW.
3. Если Steam покажет конфликт локального и облачного сейва, выбирать новую/облачную версию, которую только что загрузили.
4. Загрузить нужный слот.
5. Проверить баланс.
6. Сразу сделать новый ручной сейв, если всё работает.

Ожидаемый баланс:

```text
900 000
```

---

# 9. Если что-то пошло не так

## Сейв не виден

Проверить:

- совпадает ли имя `.sav`;
- правильный ли Root (`WinAppDataLocal`);
- правильный ли путь `Stalker2/Saved/STEAM/SaveGames/Data/`;
- не загрузили ли файл в `Thumbnails`;
- дождались ли `is_persisted = true`.

## Игра говорит, что сейв повреждён

Не продолжать играть и не перезаписывать остальные слоты.

Вернуть оригинальный backup:

```text
D639C0F24C64FC164326E8967A8DCCBE_ORIGINAL.sav
```

под исходным cloud-именем:

```text
D639C0F24C64FC164326E8967A8DCCBE.sav
```

## GFN снова залил старый сейв

Такое возможно, если GeForce NOW был запущен до завершения Steam Cloud upload.

Повторить upload и дождаться `is_persisted = true` перед следующим запуском GFN.

---

# 10. Можно ли сделать свою апку для этого?

**Да. Редактор купонов уже вполне реально сделать как маленькое Linux-приложение.**

Причём игра на компьютере для редактирования не нужна.

Самый разумный вариант — разбить проект на две части.

---

## Часть A — Save Editor

Минимальный интерфейс:

```text
[ Выбрать .sav ]

Текущий баланс: [ 56995  ]
Новый баланс:   [ 900000 ]

[ Сделать backup ]
[ Изменить и проверить ]
```

После нажатия программа должна:

1. прочитать `.sav`;
2. проверить CRC32;
3. распаковать Kraken-блоки через `pyooz`/`ooz`;
4. найти текущий баланс как little-endian `int64`;
5. отказаться от правки, если найдено не ровно одно совпадение;
6. заменить значение;
7. пересобрать только затронутый блок;
8. пересчитать CRC32;
9. снова распаковать созданный файл;
10. проверить, что payload совпадает с ожидаемым и новый баланс присутствует;
11. сохранить backup рядом, например:

```text
D639...sav.bak
```

12. создать готовый файл с исходным именем.

### Почему нужно вводить текущую сумму

Пока у нас нет полностью разобранной сериализации всех структур S.T.A.L.K.E.R. 2.

Жёсткий offset использовать нельзя — он меняется от сейва к сейву.

Текущая сумма служит безопасным идентификатором поля.

В будущем можно найти устойчивую сигнатуру структуры кошелька и вообще убрать поле «текущий баланс».

---

## Часть B — Steam Cloud uploader

Есть два варианта.

### Вариант 1 — самый надёжный для первой версии

Наша программа:

- редактирует сейв;
- делает backup;
- проверяет его;
- запускает Steam Cloud File Manager или открывает его пользователю;
- показывает точные Root/Path/AppID.

Это уже даст почти one-click workflow без риска ломать Steam-интеграцию.

### Вариант 2 — полноценная собственная загрузка

Можно встроить upload прямо в нашу программу.

Steam Cloud File Manager уже показывает, что на Linux это технически возможно. Он использует:

- Steam-клиент;
- Steamworks Remote Storage API для read/write/delete;
- CDP/CEF debug-интерфейс Steam для облачного списка/ссылок;
- `remotecache.vdf` для локального состояния и путей.

Тогда интерфейс нашей программы может выглядеть так:

```text
S.T.A.L.K.E.R. 2 Save Editor

Steam:        Connected
Steam Cloud:  Connected
App ID:       1643320

Cloud saves:
-------------------------------------------------
16:47  D639C0F2...sav    Money: 56 995
16:46  D9338CF2...sav    Money: 58 870
16:44  217BB29D...sav    Money: 48 645
-------------------------------------------------

Selected money: 56 995
New money:      [ 900000 ]

[ Backup ] [ Edit ] [ Upload to Cloud ]

Cloud status: is_persisted = true
```

### Что будет делать кнопка `Edit + Upload`

```text
Cloud download
      ↓
Backup original
      ↓
Validate CRC
      ↓
Kraken decompress
      ↓
Find current money int64
      ↓
Patch amount
      ↓
Rebuild container
      ↓
CRC32
      ↓
Round-trip validation
      ↓
Upload same Root/Path
      ↓
Wait until cloud persisted
```

---

# 11. На чём лучше написать апку

## Самый быстрый вариант: Python + Tkinter

Плюсы:

- быстро собрать;
- хорошо работает на Linux;
- можно использовать уже проверенный `pyooz` wheel;
- простая работа с `struct`, `zlib`, backup-файлами;
- не надо Electron.

Структура проекта:

```text
stalker2-save-editor/
├── app.py
├── save_format.py
├── money_editor.py
├── steam_cloud.py
├── requirements.txt
├── vendor/
│   └── ooz.abi3.so
├── backups/
└── README.md
```

### `save_format.py`

Отвечает за:

```text
parse container
validate CRC
Kraken decompress
rebuild changed blocks
recalculate CRC
round-trip test
```

### `money_editor.py`

Отвечает за:

```text
find int64(current_balance)
require exactly one candidate
replace with int64(new_balance)
```

### `steam_cloud.py`

Первая версия может просто запускать Steam Cloud File Manager.

Позже можно реализовать собственный Steam/CDP upload.

---

## Более серьёзный вариант: Rust + egui

Плюсы:

- один нативный бинарник;
- проще распространять как AppImage;
- Steam Cloud File Manager уже написан на Rust/egui, поэтому его архитектура может быть хорошим ориентиром;
- можно в будущем напрямую использовать Steamworks API.

Для первой рабочей версии Python всё равно быстрее.

---

# 12. Предлагаемый CLI

Даже если будет GUI, полезно иметь CLI для отладки:

```bash
stalker2-save info save.sav
```

Вывод:

```text
CRC: OK
Uncompressed size: 26997073
Current money candidate: 56995
Money candidates: 1
```

Редактирование:

```bash
stalker2-save set-money save.sav --current 56995 --new 900000
```

Пример результата:

```text
Backup: save.sav.bak
Money: 56995 -> 900000
CRC: OK
Round-trip: OK
Output: save.sav
```

Cloud upload в будущем:

```bash
stalker2-save cloud upload \
  --appid 1643320 \
  --root WinAppDataLocal \
  --path 'Stalker2/Saved/STEAM/SaveGames/Data/D639C0F24C64FC164326E8967A8DCCBE.sav'
```

---

# 13. Защита от случайной порчи сейва в будущей апке

Обязательно сделать следующие проверки:

- никогда не править исходник без `.bak`;
- проверять исходный CRC перед правкой;
- сумма должна быть >= 0;
- ограничить сумму разумным диапазоном, например `0..2_000_000_000`;
- поле текущего баланса должно находиться ровно один раз как `int64`;
- после сборки CRC должен совпадать;
- после сборки файл должен повторно распаковываться;
- распакованный payload должен иметь правильный размер;
- кроме ожидаемого места денег payload не должен иметь неожиданных изменений;
- cloud upload делать только после успешной локальной валидации;
- не удалять cloud backup автоматически.

---

# 14. Что хранить на случай потери чата

Сохранить вместе в одной папке:

```text
stalker2_save_editor_linux_full_guide.md
pyooz-0.0.8-cp38-abi3-manylinux_2_17_x86_64.manylinux2014_x86_64.whl
D639C0F24C64FC164326E8967A8DCCBE_ORIGINAL.sav
D639C0F24C64FC164326E8967A8DCCBE.sav
```

Также полезно оставить контрольные сейвы:

```text
217BB29D4FA4C87BD9F734AE755338CB.sav  -> 48 645
D9338CF24B87162D6472C79DF9E1CFFE.sav  -> 58 870
D639C0F24C64FC164326E8967A8DCCBE.sav  -> 56 995 (original)
```

Они очень полезны для дальнейшего reverse engineering и тестирования редактора.

---

# 15. Источники / полезные ссылки

Официальная инструкция GSC по управлению сейвами:

```text
https://www.stalker2.com/news/saves-managing-manual/
```

Steam Remote Storage:

```text
https://store.steampowered.com/account/remotestorage/
```

Steam Cloud File Manager:

```text
https://github.com/Fldicoahkiin/SteamCloudFileManager
```

Releases:

```text
https://github.com/Fldicoahkiin/SteamCloudFileManager/releases
```

---

# 16. Короткая памятка

```text
1. GFN закрыт.
2. Скачать нужный Data/*.sav из Steam Cloud.
3. Сделать backup.
4. Узнать точный текущий баланс.
5. Распаковать Kraken.
6. Найти уникальный int64(current_balance).
7. Поставить новое значение.
8. Пересобрать .sav.
9. Пересчитать CRC32.
10. Повторно распаковать и проверить.
11. Steam запустить с -cef-enable-debugging.
12. Steam Cloud File Manager -> AppID 1643320.
13. Upload в ТОТ ЖЕ Root/Path.
14. Дождаться is_persisted = true.
15. Только после этого запускать GeForce NOW.
16. Проверить деньги и сделать новый ручной сейв.
```

---

## Текущий статус проекта

Редактирование баланса **технически доказано на реальных сейвах**.

Следующий логичный шаг — собрать маленькую Linux GUI/CLI-утилиту, которая автоматизирует:

```text
.sav -> backup -> decompress -> money patch -> rebuild -> CRC -> verify
```

а затем добавить Steam Cloud upload.
