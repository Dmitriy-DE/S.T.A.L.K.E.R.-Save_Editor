from __future__ import annotations

import datetime as dt
import json
import os
from pathlib import Path
import queue
import shutil
import subprocess
import sys
import threading
import traceback
import webbrowser

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except Exception as exc:
    print("Tkinter не установлен. Ubuntu/Debian: sudo apt install python3-tk", file=sys.stderr)
    raise

from save_format import SaveError, inspect_save, patch_money
from steam_cloud import APP_ID, CloudFile, SteamCloudError, SteamWorker, discover_helper

APP_NAME = "STALKER 2 Cloud Save Editor"
APP_HOME = Path.home() / "Stalker2SaveEditor"
BACKUP_DIR = APP_HOME / "backups"
CONFIG_PATH = APP_HOME / "config.json"
RELEASES_URL = "https://github.com/Fldicoahkiin/SteamCloudFileManager/releases"


def human_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{n} B"
        n /= 1024
    return str(n)


def fmt_time(ts: int) -> str:
    try:
        return dt.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(ts)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1040x720")
        self.minsize(900, 620)
        APP_HOME.mkdir(parents=True, exist_ok=True)
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)

        self.worker: SteamWorker | None = None
        self.files: list[CloudFile] = []
        self.msgq: queue.Queue[tuple[str, object]] = queue.Queue()
        self.busy = False

        cfg = self.load_config()
        helper = cfg.get("helper_path") or discover_helper() or ""
        self.helper_var = tk.StringVar(value=helper)
        self.new_money_var = tk.StringVar(value="900000")
        self.status_var = tk.StringVar(value="Steam: не подключен")
        self.selected_var = tk.StringVar(value="Сейв не выбран")

        self.build_ui()
        self.after(100, self.poll_messages)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def load_config(self) -> dict:
        try:
            return json.loads(CONFIG_PATH.read_text("utf-8"))
        except Exception:
            return {}

    def save_config(self):
        CONFIG_PATH.write_text(
            json.dumps({"helper_path": self.helper_var.get().strip()}, ensure_ascii=False, indent=2),
            "utf-8",
        )

    def build_ui(self):
        root = ttk.Frame(self, padding=12)
        root.pack(fill="both", expand=True)

        title = ttk.Label(root, text="S.T.A.L.K.E.R. 2 — деньги + Steam Cloud", font=("TkDefaultFont", 16, "bold"))
        title.pack(anchor="w")
        ttk.Label(
            root,
            text="AppID 1643320 · полный backup перед правкой · CRC + Kraken round-trip · overwrite того же cloud-файла",
        ).pack(anchor="w", pady=(2, 10))

        helper = ttk.LabelFrame(root, text="1. Steam Cloud backend (SteamCloudFileManager)", padding=8)
        helper.pack(fill="x")
        row = ttk.Frame(helper)
        row.pack(fill="x")
        ttk.Entry(row, textvariable=self.helper_var).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Выбрать…", command=self.choose_helper).pack(side="left", padx=6)
        ttk.Button(row, text="Releases", command=lambda: webbrowser.open(RELEASES_URL)).pack(side="left")
        ttk.Button(row, text="Подключить / обновить", command=self.connect_refresh).pack(side="left", padx=(6, 0))
        ttk.Label(helper, textvariable=self.status_var).pack(anchor="w", pady=(6, 0))

        saves = ttk.LabelFrame(root, text="2. Сейвы из Steam Cloud /SaveGames/Data", padding=8)
        saves.pack(fill="both", expand=True, pady=10)
        cols = ("time", "size", "persisted", "name")
        self.tree = ttk.Treeview(saves, columns=cols, show="headings", selectmode="browse", height=12)
        self.tree.heading("time", text="Дата")
        self.tree.heading("size", text="Размер")
        self.tree.heading("persisted", text="Cloud")
        self.tree.heading("name", text="Файл")
        self.tree.column("time", width=160, anchor="w")
        self.tree.column("size", width=90, anchor="e")
        self.tree.column("persisted", width=80, anchor="center")
        self.tree.column("name", width=540, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        edit = ttk.LabelFrame(root, text="3. Изменить и сразу загрузить", padding=8)
        edit.pack(fill="x")
        r = ttk.Frame(edit)
        r.pack(fill="x")
        ttk.Label(r, textvariable=self.selected_var).pack(side="left", fill="x", expand=True)
        ttk.Label(r, text="Новые купоны:").pack(side="left", padx=(10, 4))
        ttk.Entry(r, textvariable=self.new_money_var, width=14).pack(side="left")
        self.inspect_btn = ttk.Button(r, text="Только проверить", command=self.inspect_selected)
        self.inspect_btn.pack(side="left", padx=6)
        self.upload_btn = ttk.Button(r, text="BACKUP → EDIT → UPLOAD", command=self.edit_upload)
        self.upload_btn.pack(side="left")

        ttk.Label(
            edit,
            text=(
                "Деньги определяются автоматически по подтверждённой сигнатуре структуры кошелька; "
                "если сигнатура не уникальна — программа откажется править файл."
            ),
        ).pack(anchor="w", pady=(6, 0))

        logf = ttk.LabelFrame(root, text="Лог", padding=6)
        logf.pack(fill="both", expand=False, pady=(10, 0))
        self.logbox = tk.Text(logf, height=9, wrap="word", state="disabled")
        self.logbox.pack(fill="both", expand=True)
        self.log("Готово. Steam должен быть запущен и пользователь должен быть авторизован.")

    def choose_helper(self):
        p = filedialog.askopenfilename(title="Выбрать SteamCloudFileManager / AppImage")
        if p:
            self.helper_var.set(p)
            self.save_config()

    def log(self, s: str):
        stamp = dt.datetime.now().strftime("%H:%M:%S")
        self.logbox.configure(state="normal")
        self.logbox.insert("end", f"[{stamp}] {s}\n")
        self.logbox.see("end")
        self.logbox.configure(state="disabled")

    def set_busy(self, value: bool):
        self.busy = value
        state = "disabled" if value else "normal"
        self.inspect_btn.configure(state=state)
        self.upload_btn.configure(state=state)

    def bg(self, fn):
        if self.busy:
            return
        self.set_busy(True)

        def run():
            try:
                fn()
            except Exception as exc:
                self.msgq.put(("error", f"{type(exc).__name__}: {exc}\n\n{traceback.format_exc()}"))
            finally:
                self.msgq.put(("busy", False))

        threading.Thread(target=run, daemon=True).start()

    def poll_messages(self):
        try:
            while True:
                kind, payload = self.msgq.get_nowait()
                if kind == "log":
                    self.log(str(payload))
                elif kind == "status":
                    self.status_var.set(str(payload))
                elif kind == "files":
                    self.populate(payload)  # type: ignore[arg-type]
                elif kind == "busy":
                    self.set_busy(bool(payload))
                elif kind == "error":
                    text = str(payload)
                    self.log(text.splitlines()[0])
                    messagebox.showerror(APP_NAME, text)
                elif kind == "info":
                    messagebox.showinfo(APP_NAME, str(payload))
        except queue.Empty:
            pass
        self.after(100, self.poll_messages)

    def get_worker(self) -> SteamWorker:
        helper = self.helper_var.get().strip()
        if not helper:
            raise SteamCloudError(
                "Укажи SteamCloudFileManager. Установи .deb или скачай AppImage с Releases."
            )
        if self.worker:
            self.worker.close()
        self.worker = SteamWorker(helper, log=lambda s: self.msgq.put(("log", s)))
        self.worker.start()
        self.worker.connect(APP_ID)
        self.save_config()
        return self.worker

    def connect_refresh(self):
        def job():
            self.msgq.put(("status", "Подключение к Steamworks…"))
            w = self.get_worker()
            fs = w.list_files()
            self.files = fs
            self.msgq.put(("files", fs))
            self.msgq.put(("status", f"Steam Cloud: подключено · {len(fs)} Data/*.sav"))
            self.msgq.put(("log", f"Получено {len(fs)} полноценных сейвов из облака."))
        self.bg(job)

    def populate(self, files: list[CloudFile]):
        for x in self.tree.get_children():
            self.tree.delete(x)
        for idx, f in enumerate(files):
            self.tree.insert(
                "",
                "end",
                iid=str(idx),
                values=(fmt_time(f.timestamp), human_size(f.size), "OK" if f.is_persisted else "WAIT", Path(f.name).name),
            )

    def selected(self) -> CloudFile:
        sel = self.tree.selection()
        if not sel:
            raise SteamCloudError("Сначала выбери сейв в таблице")
        return self.files[int(sel[0])]

    def on_select(self, _evt=None):
        try:
            f = self.selected()
            self.selected_var.set(Path(f.name).name)
        except Exception:
            pass

    def parse_new_money(self) -> int:
        text = self.new_money_var.get().replace(" ", "").replace("_", "")
        try:
            value = int(text)
        except Exception:
            raise SaveError("Новые купоны должны быть целым числом")
        if not (0 <= value <= 2_000_000_000):
            raise SaveError("Сумма должна быть от 0 до 2 000 000 000")
        return value

    def ensure_connection(self) -> SteamWorker:
        if self.worker and self.worker.proc and self.worker.proc.poll() is None:
            return self.worker
        return self.get_worker()

    def backup_path(self, cloud: CloudFile) -> Path:
        ts = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        return BACKUP_DIR / f"{Path(cloud.name).stem}_{ts}_ORIGINAL.sav"

    def inspect_selected(self):
        def job():
            cloud = self.selected()
            w = self.ensure_connection()
            self.msgq.put(("log", f"Скачиваю {cloud.name}…"))
            data = w.read_file(cloud.name)
            info = inspect_save(data)
            self.msgq.put(("log", f"CRC OK · packed {human_size(info.packed_size)} · raw {human_size(info.unpacked_size)}"))
            self.msgq.put(("log", f"Текущий баланс: {info.money:,}".replace(",", " ")))
            self.msgq.put(("info", f"Сейв валиден.\nТекущий баланс: {info.money:,}".replace(",", " ")))
        self.bg(job)

    def edit_upload(self):
        try:
            cloud = self.selected()
            new_money = self.parse_new_money()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        if not messagebox.askyesno(
            APP_NAME,
            f"Будет перезаписан облачный файл:\n\n{cloud.name}\n\nНовая сумма: {new_money:,}\n\n"
            "Перед изменением оригинал автоматически сохранится локально. Продолжить?".replace(",", " "),
        ):
            return

        def job():
            w = self.ensure_connection()
            self.msgq.put(("log", f"1/7 Cloud download: {cloud.name}"))
            original = w.read_file(cloud.name)

            bp = self.backup_path(cloud)
            bp.write_bytes(original)
            self.msgq.put(("log", f"2/7 Backup: {bp}"))

            info = inspect_save(original)
            self.msgq.put(("log", f"3/7 CRC/Kraken OK. Деньги: {info.money}"))

            edited, old_money, verified = patch_money(original, new_money)
            self.msgq.put(("log", f"4/7 Money: {old_money} → {verified}"))
            self.msgq.put(("log", f"5/7 Rebuild/round-trip OK. Новый размер: {human_size(len(edited))}"))

            # Also keep the exact upload image on disk for recovery/debugging.
            upload_copy = BACKUP_DIR / f"{Path(cloud.name).stem}_{dt.datetime.now().strftime('%Y%m%d-%H%M%S')}_EDITED.sav"
            upload_copy.write_bytes(edited)
            self.msgq.put(("log", f"Локальная копия edited: {upload_copy}"))

            self.msgq.put(("log", "6/7 Upload в тот же Steam RemoteStorage path…"))
            w.write_file(cloud.name, edited)
            w.sync()

            self.msgq.put(("log", "7/7 Жду is_persisted=true (до 120 секунд)…"))
            persisted = w.wait_persisted(cloud.name, len(edited), timeout=120)
            if not persisted:
                raise SteamCloudError(
                    "Файл записан через Steamworks, но is_persisted=true не подтвердился за 120 секунд. "
                    f"Backup сохранён: {bp}. Не запускай GFN, пока не проверишь облако."
                )

            fs = w.list_files()
            self.files = fs
            self.msgq.put(("files", fs))
            self.msgq.put(("log", "ГОТОВО: Steam Cloud подтвердил persisted=true."))
            self.msgq.put(("info", f"Готово.\n{old_money:,} → {verified:,} купонов\n\nCloud persisted = true\nBackup: {bp}".replace(",", " ")))

        self.bg(job)

    def on_close(self):
        try:
            self.save_config()
            if self.worker:
                self.worker.close()
        finally:
            self.destroy()


if __name__ == "__main__":
    App().mainloop()
