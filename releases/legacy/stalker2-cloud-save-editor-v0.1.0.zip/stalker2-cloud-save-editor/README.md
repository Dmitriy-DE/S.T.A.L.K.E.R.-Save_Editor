# STALKER 2 Cloud Save Editor — Linux

Небольшой GUI для сценария **Steam Cloud → backup → изменить купоны → проверить → загрузить обратно** без установки самой игры.

## Что умеет v0.1

- подключается к Steam Cloud для App ID `1643320`;
- показывает только `Stalker2/Saved/STEAM/SaveGames/Data/*.sav`;
- скачивает выбранный сейв через Steamworks;
- обязательно делает локальный backup оригинала;
- проверяет CRC32;
- распаковывает Oodle/Kraken через встроенный open-source `ooz`;
- автоматически находит поле купонов по подтверждённой сигнатуре структуры кошелька;
- меняет сумму;
- пересобирает файл без проприетарного Oodle-компрессора;
- повторно распаковывает файл и сверяет payload;
- загружает файл **под тем же cloud path/именем**;
- ждёт `is_persisted = true` перед тем, как считать операцию завершённой.

## Важное ограничение v0.1

Для безопасной пересборки изменённый сейв записывается как несжатые Kraken restart-блоки. Поэтому файл получается примерно **27 MB**, а не ~6–7 MB. Формат был проверен round-trip распаковкой; это сознательный компромисс, чтобы не использовать проприетарный Oodle compressor. В будущей версии можно добавить compact rebuild только изменённого блока.

## Что понадобится один раз

### 1. Python + Tkinter

Ubuntu/Debian:

```bash
sudo apt update
sudo apt install -y python3 python3-tk
```

`ooz.abi3.so` уже лежит в `vendor/`, pip не нужен.

### 2. SteamCloudFileManager

Нужен установленный/скачанный **SteamCloudFileManager v1.3.5** (или совместимая версия):

https://github.com/Fldicoahkiin/SteamCloudFileManager/releases

Можно установить `.deb`, либо скачать AppImage. GUI редактора умеет автоматически искать `steam-cloud-file-manager` в PATH и AppImage в `~/Downloads`.

SteamCloudFileManager используется не через клики по его GUI, а как локальный Steamworks helper (`--steam-worker`). Именно его RemoteStorage backend выполняет read/write/sync.

### 3. Steam

Steam должен быть запущен и в аккаунт нужно войти. Для этого способа upload используется Steamworks API; `-cef-enable-debugging` обычно не требуется, потому что CDP нужен SteamCloudFileManager главным образом для web/cloud-list UI, а наш редактор получает список через Steam RemoteStorage worker.

## Запуск

```bash
cd stalker2-cloud-save-editor
./run.sh
```

Опционально добавить ярлык в меню приложений:

```bash
./install-desktop.sh
```

## Использование

1. Запусти Steam и войди в нужный аккаунт.
2. Запусти редактор.
3. Если путь к SteamCloudFileManager не найден сам — нажми `Выбрать…` и укажи AppImage/binary.
4. Нажми `Подключить / обновить`.
5. Выбери нужный Data/*.sav.
6. При желании нажми `Только проверить` — программа покажет текущие купоны.
7. Введи новую сумму, например `900000`.
8. Нажми `BACKUP → EDIT → UPLOAD`.
9. Не запускай GeForce NOW, пока программа не сообщит `Cloud persisted = true`.

Backup сохраняется в:

```text
~/Stalker2SaveEditor/backups/
```

Там остаются и `*_ORIGINAL.sav`, и точная `*_EDITED.sav`, которая была отправлена в облако.

## Почему поле денег определяется автоматически

На нескольких реальных сейвах (48 645, 56 995, 58 870 и старом 22 645) подтвердился устойчивый 32-байтовый anchor непосредственно перед 32-битным значением кошелька. Программа требует **ровно одно** совпадение. Если после патча игры структура изменится и совпадений станет 0 или >1, редактор остановится вместо опасной записи наугад.

## CLI для локальной проверки

```bash
python3 cli.py info save.sav
python3 cli.py set-money save.sav 900000
```

## Восстановление

Если игра не принимает изменённый сейв, не делай новые сохранения поверх него. Возьми соответствующий `*_ORIGINAL.sav` из `~/Stalker2SaveEditor/backups/` и загрузи его в тот же cloud path через эту программу/SteamCloudFileManager.

## Проверенный cloud path

```text
Stalker2/Saved/STEAM/SaveGames/Data/<SAVE_ID>.sav
```

Root на странице Steam Remote Storage показывается как `WinAppDataLocal`, но Steamworks RemoteStorage worker работает с относительным filename выше.

## Технические детали

Формат проверенного сейва:

```text
u32 little-endian: распакованный размер
Oodle/Kraken stream
u32 little-endian: CRC32 всех предыдущих байт файла
```

Распаковка делается `ooz.decompress(file[4:-4], unpacked_size)`.

Для пересборки raw payload режется на блоки `0x40000` и каждый несжатый restart-блок получает заголовок `CC 06`. Затем рассчитывается обычный CRC32.

### Steam Cloud backend

SteamCloudFileManager реализует отдельный worker с JSON IPC и командами `Connect`, `GetFiles`, `ReadFile`, `WriteFile`, `SyncCloudFiles`. Редактор использует этот интерфейс, чтобы не автоматизировать GUI и не хранить Steam-пароль/куки.

## Безопасность

- программа не просит пароль Steam;
- пароль/2FA не читается и не сохраняется;
- работа идёт через уже авторизованный локальный Steam client;
- оригинал всегда сохраняется до upload;
- плохой CRC, неуникальная сигнатура или failed round-trip блокируют upload.

## Совместимость

Собранный `vendor/ooz.abi3.so` — Linux x86_64, glibc 2.17+, CPython 3.8+ ABI3. Для ARM64 потребуется другой wheel/библиотека.

## Источники

- SteamCloudFileManager: https://github.com/Fldicoahkiin/SteamCloudFileManager
- pyooz/ooz: https://github.com/zao/pyooz
- Официальное руководство GSC по сейвам: https://www.stalker2.com/news/saves-managing-manual/
