from __future__ import annotations

import struct
import zlib
from dataclasses import dataclass
from pathlib import Path
import sys

APP_DIR = Path(__file__).resolve().parent
VENDOR = APP_DIR / "vendor"
if str(VENDOR) not in sys.path:
    sys.path.insert(0, str(VENDOR))

try:
    import ooz  # type: ignore
except Exception as exc:  # pragma: no cover
    raise RuntimeError(
        "Не удалось загрузить vendor/ooz.abi3.so. Нужен Linux x86_64/glibc 2.17+."
    ) from exc

BLOCK_SIZE = 0x40000
UNCOMPRESSED_BLOCK_HEADER = b"\xCC\x06"

# Сигнатура непосредственно перед 32-битным балансом купонов.
# Подтверждена на четырёх реальных сохранениях пользователя (включая 2026-09-11).
MONEY_ANCHOR = bytes.fromhex(
    "0038010000000110cacfa848c8952149b51b9444000000000600000000060000"
)


class SaveError(RuntimeError):
    pass


@dataclass
class SaveInfo:
    packed_size: int
    unpacked_size: int
    stored_crc32: int
    computed_crc32: int
    crc_ok: bool
    money: int | None
    money_anchor_count: int


def validate_crc(data: bytes) -> tuple[int, int, bool]:
    if len(data) < 8:
        raise SaveError("Файл слишком маленький и не похож на STALKER 2 .sav")
    stored = struct.unpack_from("<I", data, len(data) - 4)[0]
    computed = zlib.crc32(data[:-4]) & 0xFFFFFFFF
    return stored, computed, stored == computed


def decompress_save(data: bytes) -> bytes:
    if len(data) < 8:
        raise SaveError("Файл слишком маленький")
    unpacked_size = struct.unpack_from("<I", data, 0)[0]
    if unpacked_size <= 0 or unpacked_size > 512 * 1024 * 1024:
        raise SaveError(f"Подозрительный распакованный размер: {unpacked_size}")
    try:
        raw = ooz.decompress(data[4:-4], unpacked_size)
    except Exception as exc:
        raise SaveError(f"Kraken/Oodle распаковка не удалась: {exc}") from exc
    if len(raw) != unpacked_size:
        raise SaveError(
            f"Неверный размер после распаковки: {len(raw)} вместо {unpacked_size}"
        )
    return bytes(raw)


def locate_money(raw: bytes) -> tuple[int, int]:
    positions: list[int] = []
    start = 0
    while True:
        i = raw.find(MONEY_ANCHOR, start)
        if i < 0:
            break
        positions.append(i)
        start = i + 1

    if len(positions) != 1:
        raise SaveError(
            f"Сигнатура кошелька найдена {len(positions)} раз(а), ожидалось ровно 1. "
            "Автоправка остановлена, чтобы не повредить сейв."
        )
    money_off = positions[0] + len(MONEY_ANCHOR)
    if money_off + 4 > len(raw):
        raise SaveError("Поле денег выходит за границы payload")
    money = struct.unpack_from("<I", raw, money_off)[0]
    return money_off, money


def inspect_save(data: bytes) -> SaveInfo:
    stored, computed, ok = validate_crc(data)
    if not ok:
        raise SaveError(
            f"CRC32 исходного сейва не совпадает: stored={stored:08x}, computed={computed:08x}"
        )
    raw = decompress_save(data)
    anchor_count = raw.count(MONEY_ANCHOR)
    money = None
    if anchor_count == 1:
        _, money = locate_money(raw)
    return SaveInfo(
        packed_size=len(data),
        unpacked_size=len(raw),
        stored_crc32=stored,
        computed_crc32=computed,
        crc_ok=ok,
        money=money,
        money_anchor_count=anchor_count,
    )


def rebuild_uncompressed(raw: bytes) -> bytes:
    # Ooz/Kraken принимает restart-блоки по 256 KiB с заголовком CC 06
    # как валидный несжатый поток. Это чуть увеличивает файл (~27 MB),
    # зато не требует проприетарного Oodle-компрессора.
    stream = bytearray()
    for off in range(0, len(raw), BLOCK_SIZE):
        stream += UNCOMPRESSED_BLOCK_HEADER
        stream += raw[off : off + BLOCK_SIZE]

    out = bytearray(struct.pack("<I", len(raw)))
    out += stream
    crc = zlib.crc32(out) & 0xFFFFFFFF
    out += struct.pack("<I", crc)
    return bytes(out)


def patch_money(data: bytes, new_money: int) -> tuple[bytes, int, int]:
    if not (0 <= new_money <= 2_000_000_000):
        raise SaveError("Новая сумма должна быть от 0 до 2 000 000 000")

    stored, computed, ok = validate_crc(data)
    if not ok:
        raise SaveError(
            f"Отказ от правки: CRC32 исходника плохой ({stored:08x} != {computed:08x})"
        )

    raw = bytearray(decompress_save(data))
    money_off, old_money = locate_money(raw)
    struct.pack_into("<I", raw, money_off, new_money)

    rebuilt = rebuild_uncompressed(bytes(raw))

    # Полная round-trip проверка перед возвратом файла.
    stored2, computed2, ok2 = validate_crc(rebuilt)
    if not ok2:
        raise SaveError(
            f"Внутренняя ошибка: CRC пересобранного файла неверен ({stored2:08x}/{computed2:08x})"
        )
    roundtrip = decompress_save(rebuilt)
    if roundtrip != bytes(raw):
        raise SaveError("Round-trip проверка не прошла: распакованные данные отличаются")
    _, verified_money = locate_money(roundtrip)
    if verified_money != new_money:
        raise SaveError(
            f"После проверки деньги = {verified_money}, ожидалось {new_money}"
        )

    return rebuilt, old_money, verified_money
